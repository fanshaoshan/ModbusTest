# Hardware definitions for AI-Link WF-M620-RSC1

This folder contains hardware definitions for the [AI-Link WF-W620-RSC1](https://www.seeedstudio.com/MT3620-Module-AI-Link-WF-M620-RSC1-p-2920.html) module.
